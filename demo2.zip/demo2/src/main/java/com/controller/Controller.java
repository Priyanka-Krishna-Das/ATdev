package com.controller;

import java.util.List;

import com.entity.*;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Student;

@RestController
public class Controller {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("all")  //End point which we used with URL
	public List<Student> getData()
	{
		Session session=sf.openSession();
		Criteria c=session.createCriteria(Student.class);
		List<Student> stu1 = c.list();
		session.load(1,"name");
		session.close();
		return stu1;
	}
	@PutMapping("add")
	public boolean insertData(@RequestBody Student stu1)
	{
		Session session=sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(stu1);
		tr.commit();
		session.close();
		return true;
		
	}
	@PutMapping("studentupdate")
	public boolean getUpdate(@RequestBody Student stu1)
	{
		Session s=sf.openSession();
		Transaction tr = s.beginTransaction();
		s.update(stu1);
		tr.commit();
		s.close();
		return true;
	}
	@DeleteMapping("student/{id}")
	public boolean delRecord(Student stu1)
	{
		Session s=sf.openSession();
		Transaction tr = s.beginTransaction();
		s.delete(stu1);
		tr.commit();
		s.close();
		return true;
	}

}
